<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LocationCoordinate extends Model
{
    //
}
