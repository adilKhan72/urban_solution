<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        //this seeder are for inserting 3 roles in the role table see detail in the coding of seeder.
        // $this->call(RolesTableSeeder::class);
        // $this->call(UserSeeder::class);
        // $this->call(EducationalDegreeSeeder::class);
        // $this->call(BloodGroupSeeder::class);
        // $this->call(SkillTableSeeder::class);
        // $this->call(CityTableSeeder::class);
        // $this->call(CountryTableSeeder::class);
    }
}
